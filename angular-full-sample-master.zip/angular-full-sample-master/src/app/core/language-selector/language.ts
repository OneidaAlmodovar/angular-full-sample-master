export class Language {
    constructor(public id: string, public title: string, public icon: string) {}
}
