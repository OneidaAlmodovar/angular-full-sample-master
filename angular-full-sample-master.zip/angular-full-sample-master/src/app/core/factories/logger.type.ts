export const LoggerTypes = {
    CONSOLE: 'CONSOLE'
};
