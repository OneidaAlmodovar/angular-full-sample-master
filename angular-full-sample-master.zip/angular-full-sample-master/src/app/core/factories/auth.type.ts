export const AuthTypes = {
    SKYP: 'SKYP',
    OAUTH: 'OAUTH'
};
