export const ErrorHandlerTypes = {
    SIMPLE: 'SIMPLE'
};
