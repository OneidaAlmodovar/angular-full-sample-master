export class Menu {
  constructor(public title: string, public action: string, public icon: string, public i18n: string) {}
}
