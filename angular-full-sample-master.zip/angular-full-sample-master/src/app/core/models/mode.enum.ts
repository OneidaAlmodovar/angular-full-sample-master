export enum Mode {
  VIEW, EDIT, CREATE
}
