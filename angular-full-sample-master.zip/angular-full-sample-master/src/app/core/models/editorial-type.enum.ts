export enum EditorialType {
  MARVEL = 1, DC = 2, UNKNOWN = -1
}
