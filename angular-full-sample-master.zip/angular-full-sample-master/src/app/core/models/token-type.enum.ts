export const TokenTypes = {
  BEARER: 'bearer',
  MAC: 'mac'
};
