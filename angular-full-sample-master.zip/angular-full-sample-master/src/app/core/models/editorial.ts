import {KeyText} from './key-text';

export class Editorial extends KeyText<number> {
}
