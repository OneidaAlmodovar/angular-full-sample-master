export const MessageStatus = {
    SUCCESS: 'SUCCESS',
    INFO: 'INFO',
    WARNING: 'WARNING',
    DANGER: 'DANGER'
};
