export const MessageType = {
    BLOCKING: 'BLOCKING',
    CONFIRM: 'CONFIRM'
};
