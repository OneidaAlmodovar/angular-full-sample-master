export class Villain {
  constructor(public id: number,
              public name: string,
              public editorial: number,
              public image: string) {
  }
}
