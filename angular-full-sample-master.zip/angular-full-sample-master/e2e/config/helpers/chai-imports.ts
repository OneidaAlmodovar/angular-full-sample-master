import * as chai from 'chai';
import * as cap from 'chai-as-promised';

chai.use(cap);

export const expect = chai.expect;
export const assert = chai.assert;
export const should = chai.should();
